﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBI.MVC.Model
{
  class Constants
  {
    public const uint NAMES_MAX_LENGTH = 100;
    public const string FORBIDEN_CHARS = ",\"";
  }
}
