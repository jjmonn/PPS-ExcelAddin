﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FBI.MVC.Controller
{
  using Model;
  using Model.CRUD;
  using View;
  using Utils;

  public class EmployeeController : AxisBaseController<EmployeeView, EmployeeController>
  {
    public UInt32 SelectedEntity { get; set; }

    public EmployeeController() : base(AxisType.Employee)
    {
      m_view = new EmployeeView();
      m_view.SetController(this);
      LoadView();
    }

    public override void LoadView()
    {
      base.LoadView();
      m_view.LoadView();
    }
  }
}
