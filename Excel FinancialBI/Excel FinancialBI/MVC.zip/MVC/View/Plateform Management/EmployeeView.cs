﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VIBlend.WinForms.Controls;
using FBI.Forms;

namespace FBI.MVC.View
{
  using Model;
  using Model.CRUD;
  using Controller;
  using Utils;

  public partial class EmployeeView : AxisBaseView<EmployeeController>
  {
    FbiTreeView<AxisElem> m_entitiesTV;

    public EmployeeView()
    {
      
    }

    public override void LoadView()
    {
      base.LoadView();
      m_entitiesTV = new FbiTreeView<AxisElem>(AxisElemModel.Instance.GetDictionary(AxisType.Entities));
      m_entitiesTV.ImageList = EntitiesIL;

      vSplitContainer l_splitContainer = new vSplitContainer();
      l_splitContainer.VIBlendTheme = VIBlend.Utilities.VIBLEND_THEME.OFFICESILVER;
      TableLayoutPanel1.Controls.Add(l_splitContainer, 0, 1);
      l_splitContainer.Dock = DockStyle.Fill;
      l_splitContainer.SplitterSize = 2;
      l_splitContainer.SplitterDistance = 50;

      l_splitContainer.Panel1.Controls.Add(m_entitiesTV);
      l_splitContainer.Panel2.Controls.Add(m_dgv);
      m_entitiesTV.Dock = DockStyle.Fill;
      m_dgv.Dock = DockStyle.Fill;
      SuscribeEvents();
    }

    public void SuscribeEvents()
    {
      m_entitiesTV.NodeMouseDown += OnNodeSelect;
    }

    void OnNodeSelect(object p_sender, vTreeViewMouseEventArgs p_args)
    {
      m_controller.SelectedEntity = (UInt32)p_args.Node.Value;
      DisplayEmployees(m_controller.SelectedEntity);
    }

    void DisplayEmployees(UInt32 p_entityId)
    {
      AxisElem l_entity = AxisElemModel.Instance.GetValue(p_entityId);

      if (l_entity == null || l_entity.AllowEdition == false)
        return;
      MultiIndexDictionary<UInt32, string, AxisElem> l_axisElemDic = new MultiIndexDictionary<uint, string, AxisElem>();

      foreach (AxisOwner l_axisOwner in AxisOwnerModel.Instance.GetDictionary().Values)
      {
        if (l_axisOwner.OwnerId != p_entityId)
          continue;
        AxisElem l_axisElem = AxisElemModel.Instance.GetValue(l_axisOwner.Id);

        if (l_axisElem == null)
          continue;
        l_axisElemDic.Set(l_axisElem.Id, l_axisElem.Name, l_axisElem);
      }
      LoadDGV(l_axisElemDic, AxisFilterModel.Instance.GetDictionary(AxisType.Employee).SortedValues);
    }
  }
}
